import { useEffect } from "react";
import logo from "./logo.svg";
import "./App.css";
import LearnosityConfig from "./LearnosityConfig";
import { callbacks, initializationObject } from "./ConfigObj";
import { request } from "./autoInit";

function App() {
  // const { hook, callbacksEditor } = LearnosityConfig.learnosityConfig();
  //   var initOptionsEditor = LearnosityConfig.learnosityConfig().initOptionsEditor

  useEffect(() => {
    initialization();
  }, []);

  const initialization = async () => {
    // console.log(request);
    // var request2 = JSON.stringify(request);
    // console.log(request2);
    // var initializationObject = {
    //   security: {
    //     consumer_key: "twRp5spenrCfVAa6",
    //     domain: "localhost:3000",
    //     timestamp: "20210804-0519",
    //     signature:
    //       "e96f3cb6d731d1a38d16a14342342ea02822d96f592ed58eef38b5fd8bc9fdff",
    //   },
    //   request: {
    //     user: {
    //       id: "demo_student",
    //     },
    //     mode: "item_edit",
    //     reference: "my-item-reference",
    //     config: {
    //       global: {
    //         disable_onbeforeunload: true,
    //         // All tags of type "internal_category_uuid" are hidden in the UI
    //         hide_tags: [
    //           {
    //             type: "internal_category_uuid",
    //           },
    //         ],
    //       },
    //       item_edit: {
    //         item: {
    //           back: true,
    //           columns: true,
    //           answers: true,
    //           scoring: true,
    //           reference: {
    //             edit: false,
    //             show: false,
    //             prefix: "LEAR_", // The reference for a new item will start with LEAR_
    //           },
    //           save: true,
    //           status: false,
    //           dynamic_content: true,
    //           shared_passage: true,
    //         },
    //         widget: {
    //           delete: false,
    //           edit: true,
    //         },
    //       },
    //       item_list: {
    //         item: {
    //           status: true,
    //           url: "http://myApp.com/items/:reference/edit",
    //         },
    //         toolbar: {
    //           add: true,
    //           browse: {
    //             controls: [
    //               {
    //                 type: "hierarchy",
    //                 hierarchies: [
    //                   {
    //                     reference: "CCSS_Math_Hierarchy",
    //                     label: "CCSS Math",
    //                   },
    //                   {
    //                     reference: "CCSS_ELA_Hierarchy",
    //                     label: "CCSS ELA",
    //                   },
    //                   {
    //                     reference: "Demo_Items_Hierarchy",
    //                     label: "Demo Items",
    //                   },
    //                 ],
    //               },
    //               {
    //                 type: "tag",
    //                 tag: {
    //                   type: "difficulty",
    //                   label: "Difficulty",
    //                 },
    //               },
    //               {
    //                 type: "tag",
    //                 tag: {
    //                   type: "content_provider",
    //                   label: "Source",
    //                 },
    //               },
    //             ],
    //           },
    //         },
    //         filter: {
    //           restricted: {
    //             current_user: true,
    //             tags: {
    //               all: [
    //                 {
    //                   type: "Alignment",
    //                   name: ["def456", "abc123"],
    //                 },
    //                 {
    //                   type: "Course",
    //                 },
    //               ],
    //               either: [
    //                 {
    //                   type: "Grade",
    //                   name: "4",
    //                 },
    //                 {
    //                   type: "Grade",
    //                   name: "5",
    //                 },
    //                 {
    //                   type: "Subject",
    //                   name: ["Math", "Science"],
    //                 },
    //               ],
    //               none: [
    //                 {
    //                   type: "Grade",
    //                   name: "6",
    //                 },
    //               ],
    //             },
    //           },
    //         },
    //       },
    //       dependencies: {
    //         question_editor_api: {
    //           init_options: {},
    //         },
    //         questions_api: {
    //           init_options: {},
    //         },
    //       },
    //       widget_templates: {
    //         back: true,
    //         save: true,
    //         widget_types: {
    //           default: "questions",
    //           show: true,
    //         },
    //       },
    //       container: {
    //         height: "auto",
    //         fixed_footer_height: 0,
    //         scroll_into_view_selector: "body",
    //       },
    //       label_bundle: {
    //         // German translation and date/time format changes
    //         // Generic components and partials
    //         backButton: "Zurück",
    //         loadingText: "Wird geladen",
    //         modalClose: "Schließen",
    //         saveButton: "Speichern",
    //         duplicateButton: "Duplikat",

    //         // itemList > dates (using Moment.js)
    //         dateTimeLocale: "",
    //         toolTipDateTimeSeparator: "um",
    //         toolTipDateFormat: "DD-MM-YYYY",
    //         toolTipTimeFormat: "HH:MM:SS",
    //       },
    //     },
    //   },
    // };

    // var callbacks = {
    //   readyListener: function () {
    //     console.log("Learnosity Author API is ready");
    //   },
    //   errorListener: function (e) {
    //     //callback to occur on error
    //     console.log("Error code ", e.code);
    //     console.log("Error message ", e.message);
    //     console.log("Error name ", e.name);
    //     console.log("Error name ", e.title);
    //   },
    // };

    console.log({ initializationObject });
    var authorApp = window.LearnosityAuthor.init(
      initializationObject,
      callbacks
    );
    // var authorApp = await window.LearnosityAuthor.init(request);
    console.log({ authorApp });
    // console.log(editor.getWidget());
  };

  return (
    <div className="App">
      <div className="new-course">
        <div id="learnosity-author"></div>
      </div>
    </div>
  );
}

export default App;
